#!bin/bash

i=1
for dat in $(ls); do
    echo “File ke $1 adalah $dat”
    n=$n+1
done