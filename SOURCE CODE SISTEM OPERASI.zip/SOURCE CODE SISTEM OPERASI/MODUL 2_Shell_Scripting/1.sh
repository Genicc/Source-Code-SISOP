#!bin/bash

echo 'Single Quote ini dengan adanya "Double Quote" di antaranya';
echo "Double quote dengan \"double quote\" kah?";
echo "isi direktori `pwd` adalah `ls|wc -l` file"